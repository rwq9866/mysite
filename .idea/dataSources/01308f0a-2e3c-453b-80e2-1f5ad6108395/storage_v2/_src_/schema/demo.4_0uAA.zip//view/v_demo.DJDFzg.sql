create view v_demo as
  select sum(`demo`.`demo`.`sal`) AS `sum(sal)`
  from `demo`.`demo`;

